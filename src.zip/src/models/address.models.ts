export class Address {
    id: number;
    user_id: number;
    title: string;
    address: string;
    longitude: string;
    latitude: string;
}