export class StatusLog {
    id: number;
    user_id: number;
    appointment_id: number;
    status: string;
    updated_at: string;
    created_at: string;
}