export class Category {
    id: number;
    parent_id: number;
    title: string;
    image_url: string;
    secondary_image_url: string;
    selected: boolean;
    price: number;
    price_type: string;
}