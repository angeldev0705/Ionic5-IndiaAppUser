export class Faq {
    id: number;
    title: string;
    short_description: string;
    description: string;
}