export class qrResponse{
    message: string;
}