export class Setting {
    id: number;
    key: string;
    value: string;
}