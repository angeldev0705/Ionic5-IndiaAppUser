export class Country {
    name: string;
    callingCodes: any;
    code: string;
    alpha2Code: string;
}