export class MyLocation {
    name: string;
    lat: string;
    lng: string;
}