export class ProviderPortfolio {
    id: number;
    provider_id: number;
    image_url: string;
    link: string;
}