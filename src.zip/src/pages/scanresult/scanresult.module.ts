import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ScanresultPage } from './scanresult';

@NgModule({
  declarations: [
    ScanresultPage,
  ],
  imports: [
    IonicPageModule.forChild(ScanresultPage),
  ],
})
export class ScanresultPageModule {}
